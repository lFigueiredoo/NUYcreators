﻿# Schema, permissões, índices e auditoria — proposta

Fonte integral: infra/appwrite/academy-schema.ts. Versão academy-001-proposal-v1.1, fora do provisioner v001. Nenhuma migração foi executada.

## Tabelas

academy_categories, academy_courses, academy_modules, academy_lessons, academy_materials, academy_progress, community_comments, community_reports e community_moderation_events.

## Índices e duplicidade

Slug único para categorias e cursos; posição única por curso nos módulos e por módulo nas aulas; progresso único por usuário/aula; denúncia única por comentário/denunciante. Índices de filtros e ordenação cobrem catálogo, aulas, materiais, comentários e auditoria. FULLTEXT em academy_courses.searchText é proposto separadamente porque o manifesto atual só expressa key/unique.

## Permissões e auditoria

Bucket academy-media proposto como privado, fileSecurity=true, MP4/PDF; nenhum bucket foi criado. Linhas publicadas são legíveis apenas por sessão Creator elegível. Rascunhos, denúncias, comentários não visíveis e eventos de moderação ficam limitados à equipe autorizada. Progresso individual só pelo titular; Admin vê resumo mínimo. Escritas devem derivar o ator da sessão, validar capacidade e referência, registrar fromStatus/toStatus, actorId, reason e createdAt em evento imutável. Exclusão física requer checagem de dependências e preservação de auditoria.

Validar no staging: suporte aos tipos/índices no Appwrite instalado, ACL por linha, rollback, reordenação com índices únicos e acesso privado/expiração de mídia.
