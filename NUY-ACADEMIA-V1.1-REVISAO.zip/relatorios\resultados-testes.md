﻿# Resultados dos testes — Academia V1.1

Resultados da revisão local anterior. O empacotamento não executou migração ou teste de escrita remota.

| Verificação | Resultado |
| --- | --- |
| npm run typecheck | Passou. |
| npm test, padrão com 24 workers | 194 passaram; 1 timeout de cinco segundos em tests/unit/onboarding-endpoint.test.ts. |
| npx vitest run --maxWorkers=4 | 24 arquivos e 195 testes passaram; repetido com sucesso após a última alteração no schema. |
| npm run build | Passou em Next.js 16.3.8; nove rotas da Academia no manifesto. |
| E2E Academia completo | 5 cenários passaram; capturas em 1440×900, 390×844 e 375×667. |
| E2E de permissões ampliado | Passou isoladamente: visitante ao login; Creator sem acesso à lista, comentários e editor Admin. |

O timeout intermitente foi da sonda de endpoint já citada na documentação V1.0. A suíte completa passou duas vezes com quatro workers. O teste afetado não foi alterado.

O E2E usa stub Appwrite local. Permissões de linha, índices reais, uploads e URLs privadas ainda requerem teste no staging autorizado.
