﻿# Pacote de revisão — Academia NUY V1.1

Abra docs/academia-v1.1-revisao.md para o relatório completo.

Capturas originais, em resolução integral:
- artifacts/academy-before-v1.1/: 24 PNGs Antes V1.0
- artifacts/academy/: 24 PNGs Depois V1.1

As três folhas de contato em folhas-de-contato/ são composições dos PNGs originais, com tela e versão identificadas. Os originais não foram redimensionados nem regravados.

relatorios/ contém inventário, matriz de funcionalidades, resultados dos testes e resumo do schema. A fonte integral do schema está em infra/appwrite/academy-schema.ts. manifesto-sha256.txt registra hashes para conferência.

Este pacote é somente para revisão. Não contém credenciais e não altera Appwrite.
