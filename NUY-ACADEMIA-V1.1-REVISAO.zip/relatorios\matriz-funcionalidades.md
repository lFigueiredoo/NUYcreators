﻿# Matriz de funcionalidades — Academia V1.1

| Funcionalidade | Estado | Limite atual |
| --- | --- | --- |
| Catálogo, busca, categoria e paginação Creator | Pronta localmente | Exercitada com fixture de 107 cursos; dados reais dependem de schema/ACL. |
| Detalhe, percurso e aula Creator | Pronta localmente | UI e estados de preparação/erro; conteúdo em fixture. |
| Lista, categorias, comentários, denúncias e progresso Admin | Pronta localmente | UI, leituras e guards; ações de escrita desabilitadas. |
| Editor de curso existente | Pronta localmente | Hidrata módulos, aulas e materiais, preservando IDs/ordem; prévia local. |
| Estados e transições de comentários | Pronta localmente | Status desconhecido nunca se torna visível; auditoria proposta. |
| Schema, índices e permissões por linha | Pendente de backend | Proposta aditiva sem migração; validar no Appwrite staging instalado. |
| Progresso e comentários persistentes | Pendente de backend | Exigem política por usuário, autoria, integridade e auditoria. |
| Capas, MP4 e PDF privados | Pendente de backend | Resolver de URL autorizada e teste real no navegador ainda ausentes. |
| Salvar, publicar, arquivar, excluir e moderar | Bloqueada por segurança | Controles desabilitados até mutações autorizadas, ACL e auditoria validadas. |
| Upload MP4/PDF e abertura privada | Bloqueada por segurança | Sem bucket, credenciais, fluxo chunked e acesso por aula validados. |
| Ativação em Preview/Production e deploy | Bloqueada por segurança | Exige staging isolado e aprovação posterior. |

A flag APPWRITE_ACADEMY_ENABLED permanece desligada por ausência fora do stub local.
