﻿# Inventário da revisão Academia V1.1

## Arquivos ajustados nesta revisão

- docs/academia-v1.1-revisao.md: relatório atual.
- docs/academia-implementacao-local.md: referência à V1.1.
- infra/appwrite/academy-schema.ts: proposta aditiva de nove tabelas, índices e auditoria.
- src/features/academy/domain.ts: tipos, estados e transições de moderação.
- src/features/academy/services/read.ts: consultas diretas, paginação, agregação e indisponibilidade.
- src/features/academy/components/creator.tsx: catálogo mobile, textos e capa autorizada.
- src/features/academy/components/admin.tsx: fila de comentários e listas paginadas.
- src/features/academy/components/editor.tsx: hidratação de módulos, aulas e materiais.
- src/features/academy/academy.module.css: compactação mobile e estilos de paginação.
- src/app/(protected)/app/academia/: leituras e paginação nas rotas Creator.
- src/app/(protected)/admin/academia/: leituras e paginação nas rotas Admin.
- tests/e2e-app/academy.spec.ts: fluxos, permissões, 107 cursos e capturas.
- tests/unit/academy-schema.test.ts e academy-moderation.test.ts: contratos locais.
- tests/support/appwrite-stub/academy-fixtures.mjs, server.mjs e tests/support/stack.d.mts: fixture isolada.

## Arquivos incluídos para revisão de contexto

O ZIP contém o módulo Academia e suas nove rotas, o schema, testes pertinentes, 48 PNGs originais e três folhas de contato. infra/appwrite/schema.ts foi incluído para explicar o tipo Table usado na proposta. O inventário de estado abaixo inclui mudanças preexistentes não relacionadas à Academia; não é um diff exclusivo da V1.1.

## Estado de trabalho no momento do empacotamento

 M .env.example
 M infra/appwrite/capabilities.ts
 M infra/appwrite/key-scopes.ts
 M infra/appwrite/safety.ts
 M src/app/(protected)/app/desafios/[slug]/page.tsx
 M src/app/(protected)/app/page.tsx
 M src/app/(protected)/app/recompensas/page.tsx
 M src/features/admin/components/nav-items.ts
 M src/features/workspace/components/app-nav.tsx
 M src/features/workspace/components/challenges-screen.tsx
 M src/features/workspace/components/dashboard-screen.tsx
 M src/features/workspace/components/navigation.tsx
 M src/features/workspace/services/notifications.ts
 M src/features/workspace/services/ranking.ts
 M src/features/workspace/services/rewards.ts
 M src/features/workspace/styles/app.module.css
 M src/lib/env/schema.ts
 M tests/support/appwrite-stub/server.mjs
 M tests/support/stack.d.mts
 M tests/support/stack.mjs
 M tests/unit/admin-guard.test.ts
 M tests/unit/app-no-fake-data.test.ts
 M tests/unit/cloud-safety.test.ts
 M tests/unit/environment.test.ts
 M tests/unit/project-identity.test.ts
?? NUY-ACADEMIA-REVISAO-V1.zip
?? docs/academia-implementacao-local.md
?? docs/academia-v1.1-revisao.md
?? docs/fase-a-academia-comunidade.md
?? docs/staging-isolado.md
?? infra/appwrite/academy-schema.ts
?? src/app/(protected)/admin/academia/
?? src/app/(protected)/app/academia/
?? src/features/academy/
?? src/lib/env/protected-project.ts
?? tests/e2e-app/academy.spec.ts
?? tests/support/appwrite-stub/academy-fixtures.mjs
?? tests/unit/academy-moderation.test.ts
?? tests/unit/academy-schema.test.ts

Nenhum arquivo de código ou CSS foi modificado para preparar este ZIP.

