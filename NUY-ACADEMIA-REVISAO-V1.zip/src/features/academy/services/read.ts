import 'server-only';
import { Query } from 'node-appwrite';
import {
  databaseId,
  listTableRows,
  opsTables,
  sessionTables,
  type Tables,
} from '@/lib/appwrite/data';
import {
  academyEnabled,
  type AcademyCategory,
  type AcademyComment,
  type AcademyCourse,
  type AcademyLesson,
  type AcademyLoad,
  type AcademyMaterial,
  type AcademyModule,
  type AcademyProgress,
  type AcademyReport,
} from '../domain';

type Row = Record<string, unknown>;
const string = (value: unknown) => (typeof value === 'string' ? value : '');
const optional = (value: unknown) => string(value) || null;
const number = (value: unknown) =>
  typeof value === 'number' && Number.isFinite(value) ? value : 0;
const courseStatus = (value: unknown): AcademyCourse['status'] =>
  value === 'published' || value === 'archived' ? value : 'draft';

export const mapCategory = (row: Row): AcademyCategory => ({
  id: string(row.$id),
  name: string(row.name),
  slug: string(row.slug),
});
export const mapCourse = (row: Row): AcademyCourse => ({
  id: string(row.$id),
  slug: string(row.slug),
  title: string(row.title),
  summary: string(row.summary),
  description: string(row.description),
  categoryId: optional(row.categoryId),
  status: courseStatus(row.status),
  order: number(row.order),
});
export const mapModule = (row: Row): AcademyModule => ({
  id: string(row.$id),
  courseId: string(row.courseId),
  title: string(row.title),
  summary: string(row.summary),
  order: number(row.order),
});
export const mapLesson = (row: Row): AcademyLesson => ({
  id: string(row.$id),
  courseId: string(row.courseId),
  moduleId: string(row.moduleId),
  title: string(row.title),
  summary: string(row.summary),
  durationSeconds: typeof row.durationSeconds === 'number' ? row.durationSeconds : null,
  videoFileId: optional(row.videoFileId),
  status: courseStatus(row.status),
  order: number(row.order),
});
export const mapMaterial = (row: Row): AcademyMaterial => ({
  id: string(row.$id),
  courseId: string(row.courseId),
  lessonId: optional(row.lessonId),
  title: string(row.title),
  kind: row.kind === 'link' ? 'link' : 'pdf',
  fileId: optional(row.fileId),
  url: optional(row.url),
});
export const mapComment = (row: Row): AcademyComment => ({
  id: string(row.$id),
  targetType: row.targetType === 'challenge' ? 'challenge' : 'lesson',
  targetId: string(row.targetId),
  parentId: optional(row.parentId),
  authorId: string(row.authorId),
  body: string(row.body),
  status: row.status === 'hidden' ? 'hidden' : 'visible',
  createdAt: string(row.createdAt),
});
export const mapReport = (row: Row): AcademyReport => ({
  id: string(row.$id),
  commentId: string(row.commentId),
  reporterId: string(row.reporterId),
  reason: string(row.reason),
  status: string(row.status),
});
export const mapProgress = (row: Row): AcademyProgress => ({
  userId: string(row.userId),
  courseId: string(row.courseId),
  lessonId: string(row.lessonId),
  completedAt: string(row.completedAt),
});

async function read<T>(
  client: () => Tables,
  tableId: string,
  map: (row: Row) => T,
  queries: string[] = [],
): Promise<AcademyLoad<T>> {
  if (!academyEnabled()) return { state: 'pending', items: [] };
  try {
    const result = await listTableRows(client(), {
      databaseId: databaseId(),
      tableId,
      queries: [...queries, Query.limit(100)],
    });
    return { state: 'ok', items: result.rows.map((row) => map(row as Row)) };
  } catch {
    // A flag pode ter sido ligada antes do schema ou a leitura pode estar negada.
    // Ambas são indisponibilidade, nunca catálogo vazio inventado.
    return { state: 'unavailable', items: [] };
  }
}

function fromSession<T>(
  secret: string,
  tableId: string,
  map: (row: Row) => T,
  queries: string[] = [],
) {
  if (!academyEnabled()) return Promise.resolve({ state: 'pending', items: [] } as AcademyLoad<T>);
  return read(() => sessionTables(secret), tableId, map, queries);
}
function fromAdmin<T>(tableId: string, map: (row: Row) => T, queries: string[] = []) {
  if (!academyEnabled()) return Promise.resolve({ state: 'pending', items: [] } as AcademyLoad<T>);
  return read(() => opsTables(), tableId, map, queries);
}

export async function creatorAcademyCatalog(secret: string) {
  const [courses, categories] = await Promise.all([
    fromSession(secret, 'academy_courses', mapCourse, [Query.equal('status', 'published')]),
    fromSession(secret, 'academy_categories', mapCategory, [Query.equal('active', true)]),
  ]);
  return { courses, categories };
}

export async function creatorAcademyCourse(secret: string, slug: string) {
  const catalog = await creatorAcademyCatalog(secret);
  const course = catalog.courses.items.find((item) => item.slug === slug) ?? null;
  if (!course)
    return {
      ...catalog,
      course,
      modules: { state: catalog.courses.state, items: [] } as AcademyLoad<AcademyModule>,
      lessons: { state: catalog.courses.state, items: [] } as AcademyLoad<AcademyLesson>,
      materials: { state: catalog.courses.state, items: [] } as AcademyLoad<AcademyMaterial>,
    };
  const [modules, lessons, materials] = await Promise.all([
    fromSession(secret, 'academy_modules', mapModule, [Query.equal('courseId', course.id)]),
    fromSession(secret, 'academy_lessons', mapLesson, [
      Query.equal('courseId', course.id),
      Query.equal('status', 'published'),
    ]),
    fromSession(secret, 'academy_materials', mapMaterial, [Query.equal('courseId', course.id)]),
  ]);
  return { ...catalog, course, modules, lessons, materials };
}

export function lessonComments(secret: string, lessonId: string) {
  return fromSession(secret, 'community_comments', mapComment, [
    Query.equal('targetType', 'lesson'),
    Query.equal('targetId', lessonId),
    Query.equal('status', 'visible'),
  ]);
}

export function challengeComments(secret: string, challengeId: string) {
  return fromSession(secret, 'community_comments', mapComment, [
    Query.equal('targetType', 'challenge'),
    Query.equal('targetId', challengeId),
    Query.equal('status', 'visible'),
  ]);
}

export function adminAcademyCatalog() {
  return fromAdmin('academy_courses', mapCourse);
}

export function adminAcademyCategories() {
  return fromAdmin('academy_categories', mapCategory);
}

export function adminAcademyComments() {
  return fromAdmin('community_comments', mapComment);
}

export function adminAcademyReports() {
  return fromAdmin('community_reports', mapReport);
}

export function adminAcademyProgress() {
  return fromAdmin('academy_progress', mapProgress);
}
