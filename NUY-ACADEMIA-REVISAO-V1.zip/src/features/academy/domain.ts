export type AcademyCategory = { id: string; name: string; slug: string };
export type AcademyCourse = {
  id: string;
  slug: string;
  title: string;
  summary: string;
  description: string;
  categoryId: string | null;
  status: 'draft' | 'published' | 'archived';
  order: number;
};
export type AcademyModule = {
  id: string;
  courseId: string;
  title: string;
  summary: string;
  order: number;
};
export type AcademyLesson = {
  id: string;
  courseId: string;
  moduleId: string;
  title: string;
  summary: string;
  durationSeconds: number | null;
  videoFileId: string | null;
  status: 'draft' | 'published' | 'archived';
  order: number;
};
export type AcademyMaterial = {
  id: string;
  courseId: string;
  lessonId: string | null;
  title: string;
  kind: 'pdf' | 'link';
  fileId: string | null;
  url: string | null;
};
export type AcademyComment = {
  id: string;
  targetType: 'lesson' | 'challenge';
  targetId: string;
  parentId: string | null;
  authorId: string;
  body: string;
  status: 'visible' | 'hidden';
  createdAt: string;
};
export type AcademyReport = {
  id: string;
  commentId: string;
  reporterId: string;
  reason: string;
  status: string;
};
export type AcademyProgress = {
  userId: string;
  courseId: string;
  lessonId: string;
  completedAt: string;
};
export type AcademyLoad<T> =
  | { state: 'pending'; items: T[] }
  | { state: 'ok'; items: T[] }
  | { state: 'unavailable'; items: T[] };

export function academyEnabled() {
  return process.env.APPWRITE_ACADEMY_ENABLED === 'true';
}
