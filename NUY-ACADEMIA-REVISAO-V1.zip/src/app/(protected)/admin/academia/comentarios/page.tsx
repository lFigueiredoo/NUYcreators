import { AdminAcademyComments } from '@/features/academy/components/admin';
import { adminAcademyComments, adminAcademyReports } from '@/features/academy/services/read';
import { requireStaff } from '@/lib/security/authorization';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Comentários · Academia NUY' };

export default async function AdminAcademyCommentsPage() {
  await requireStaff('moderate');
  const [comments, reports] = await Promise.all([adminAcademyComments(), adminAcademyReports()]);
  return <AdminAcademyComments comments={comments} reports={reports} />;
}
