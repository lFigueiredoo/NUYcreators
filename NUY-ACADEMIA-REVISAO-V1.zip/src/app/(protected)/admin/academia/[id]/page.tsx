import { AcademyEditor } from '@/features/academy/components/editor';
import { AcademyNotice } from '@/features/academy/components/creator';
import { adminAcademyCatalog, adminAcademyCategories } from '@/features/academy/services/read';
import { requireStaff } from '@/lib/security/authorization';
import { notFound } from 'next/navigation';
import Link from 'next/link';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Editar treinamento · Academia NUY' };

export default async function EditAcademyCoursePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireStaff('manage-catalog');
  const { id } = await params;
  const [catalog, categories] = await Promise.all([
    adminAcademyCatalog(),
    adminAcademyCategories(),
  ]);
  if (catalog.state !== 'ok')
    return (
      <div>
        <Link href="/admin/academia">Voltar à Academia</Link>
        <AcademyNotice text="Não foi possível carregar este treinamento neste ambiente." />
      </div>
    );
  const course = catalog.items.find((item) => item.id === id);
  if (!course) notFound();
  return <AcademyEditor course={course} categories={categories.items} />;
}
