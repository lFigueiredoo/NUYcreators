import { AdminAcademyHome } from '@/features/academy/components/admin';
import { adminAcademyCatalog } from '@/features/academy/services/read';
import { requireStaff } from '@/lib/security/authorization';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Academia NUY' };

export default async function AdminAcademyPage() {
  await requireStaff('manage-catalog');
  return <AdminAcademyHome courses={await adminAcademyCatalog()} />;
}
