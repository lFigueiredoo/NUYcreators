# Rotas implementadas

| Rota | Tela | Acesso |
| --- | --- | --- |
| `/app/academia` | Início, catálogo, busca e categorias | Sessão Creator |
| `/app/academia/[slug]` | Detalhe, módulos, aulas e materiais | Sessão Creator |
| `/app/academia/[slug]/aulas/[lessonId]` | Aula, player condicionado, materiais, conversa e progresso | Sessão Creator |
| `/admin/academia` | Lista de treinamentos | `manage-catalog` |
| `/admin/academia/novo` | Editor e prévia local | `manage-catalog` |
| `/admin/academia/[id]` | Edição local de treinamento | `manage-catalog` |
| `/admin/academia/categorias` | Lista e formulário | `manage-catalog` |
| `/admin/academia/comentarios` | Comentários e denúncias | `moderate` |
| `/admin/academia/progresso` | Resumo de conclusões | `view-audit` |

A conversa também aparece na rota preexistente `/app/desafios/[slug]`. Todas as páginas usam os layouts e o login atuais. Ações de escrita e mídia privada permanecem desabilitadas.
