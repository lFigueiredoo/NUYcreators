# Resultados detalhados dos testes locais

Resultados observados em 13/10/2026. Este pacote não reexecutou testes; logs brutos de terminal não foram persistidos.

| Comando | Resultado | Escopo |
| --- | --- | --- |
| `npm run typecheck` | Passou; `tsc --noEmit`, código 0. | Tipos após fila de denúncias. Build final também executou TypeScript. |
| `npm test` | 23 arquivos e 193 testes passaram. | Suíte unitária, incluindo schema e guards. |
| `npm run build` | Passou; Next.js 16.3.8 listou nove rotas. | Build final após player HTML5 condicionado. |
| `npx playwright test --config playwright.app.config.ts tests/e2e-app/academy.spec.ts` | Quatro testes passaram em 30,1 s. | `next start` com stub Appwrite local; nenhuma escrita remota. |

## Casos E2E
1. Creator: catálogo, detalhe, aula, conversa em leitura e controles privados bloqueados; três viewports.
2. Permissões: visitante vai ao login; Creator não abre Admin.
3. Busca/categoria: filtro funcional; rascunho invisível.
4. Admin: lista, categorias, comentários/denúncias, progresso, editor/novo, prévia, salvar desabilitado; três viewports e ausência de overflow.

As 24 imagens vêm do E2E. Ele antecedeu apenas a adição opcional do elemento `<video>`; o fallback sem URL ficou igual e o build posterior passou. Não se testou reprodução privada, byte-range, upload, PDF autorizado nem Appwrite remoto.

Uma execução anterior teve timeout em sondas TLS de `onboarding-endpoint.test.ts` sob workers concorrentes; o arquivo passou isolado e a suíte inteira passou na repetição. Isso não valida a rede da Academia.

Os PNGs foram conferidos por assinatura, largura e altura mínima. A altura pode superar a viewport porque as capturas usam `fullPage`.
