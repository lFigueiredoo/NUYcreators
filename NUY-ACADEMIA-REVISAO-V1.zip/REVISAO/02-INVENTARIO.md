# Inventário de componentes e arquivos

## Academia
- `src/features/academy/domain.ts`: tipos e flag de ativação.
- `src/features/academy/services/read.ts`: leituras condicionadas e estados `pending/ok/unavailable`.
- `src/features/academy/components/creator.tsx`: catálogo, detalhe, aula e player condicionado.
- `src/features/academy/components/admin.tsx`: lista, categorias, moderação e progresso.
- `src/features/academy/components/editor.tsx`: editor local e prévia.
- `src/features/academy/components/comments.tsx`: conversa compartilhada por aula/desafio.
- `src/features/academy/academy.module.css`: identidade visual e responsividade.
- `src/app/(protected)/app/academia/`: três arquivos de rota Creator.
- `src/app/(protected)/admin/academia/`: seis arquivos de rota Admin.
- `infra/appwrite/academy-schema.ts`: oito tabelas e bucket propostos.
- `tests/e2e-app/academy.spec.ts`, `tests/unit/academy-schema.test.ts`, `tests/support/appwrite-stub/academy-fixtures.mjs`: validação local.
- `docs/academia-implementacao-local.md`: documento entregue.

## Integração em arquivos existentes
- `src/features/workspace/components/navigation.tsx` e `src/features/admin/components/nav-items.ts`: menus.
- `src/app/(protected)/app/desafios/[slug]/page.tsx` e `src/features/workspace/components/challenges-screen.tsx`: conversa no desafio.
- `tests/support/appwrite-stub/server.mjs`, `tests/support/stack.mjs` e `tests/support/stack.d.mts`: stub E2E.
- `.env.example`: flag desativada por padrão.
- Testes existentes de navegação e estados sem dados também foram ajustados.

## Estado Git observado

Esta é a lista total do workspace, sem atribuição de autoria. Parte das alterações já existia antes da Academia. Nenhum commit foi feito.

```text
 M .env.example
 M infra/appwrite/capabilities.ts
 M infra/appwrite/key-scopes.ts
 M infra/appwrite/safety.ts
 M src/app/(protected)/app/desafios/[slug]/page.tsx
 M src/app/(protected)/app/page.tsx
 M src/app/(protected)/app/recompensas/page.tsx
 M src/features/admin/components/nav-items.ts
 M src/features/workspace/components/app-nav.tsx
 M src/features/workspace/components/challenges-screen.tsx
 M src/features/workspace/components/dashboard-screen.tsx
 M src/features/workspace/components/navigation.tsx
 M src/features/workspace/services/notifications.ts
 M src/features/workspace/services/ranking.ts
 M src/features/workspace/services/rewards.ts
 M src/features/workspace/styles/app.module.css
 M src/lib/env/schema.ts
 M tests/support/appwrite-stub/server.mjs
 M tests/support/stack.d.mts
 M tests/support/stack.mjs
 M tests/unit/admin-guard.test.ts
 M tests/unit/app-no-fake-data.test.ts
 M tests/unit/cloud-safety.test.ts
 M tests/unit/environment.test.ts
 M tests/unit/project-identity.test.ts
?? docs/academia-implementacao-local.md
?? docs/fase-a-academia-comunidade.md
?? docs/staging-isolado.md
?? infra/appwrite/academy-schema.ts
?? src/app/(protected)/admin/academia/[id]/page.tsx
?? src/app/(protected)/admin/academia/categorias/page.tsx
?? src/app/(protected)/admin/academia/comentarios/page.tsx
?? src/app/(protected)/admin/academia/novo/page.tsx
?? src/app/(protected)/admin/academia/page.tsx
?? src/app/(protected)/admin/academia/progresso/page.tsx
?? src/app/(protected)/app/academia/[slug]/aulas/[lessonId]/page.tsx
?? src/app/(protected)/app/academia/[slug]/page.tsx
?? src/app/(protected)/app/academia/page.tsx
?? src/features/academy/academy.module.css
?? src/features/academy/components/admin.tsx
?? src/features/academy/components/comments.tsx
?? src/features/academy/components/creator.tsx
?? src/features/academy/components/editor.tsx
?? src/features/academy/domain.ts
?? src/features/academy/services/read.ts
?? src/lib/env/protected-project.ts
?? tests/e2e-app/academy.spec.ts
?? tests/support/appwrite-stub/academy-fixtures.mjs
?? tests/unit/academy-schema.test.ts```

## Arquivos fonte efetivamente incluídos neste ZIP

- `src/app/(protected)/app/academia/[slug]/aulas/[lessonId]/page.tsx`
- `src/app/(protected)/app/academia/[slug]/page.tsx`
- `src/app/(protected)/app/academia/page.tsx`
- `src/app/(protected)/admin/academia/[id]/page.tsx`
- `src/app/(protected)/admin/academia/categorias/page.tsx`
- `src/app/(protected)/admin/academia/comentarios/page.tsx`
- `src/app/(protected)/admin/academia/novo/page.tsx`
- `src/app/(protected)/admin/academia/page.tsx`
- `src/app/(protected)/admin/academia/progresso/page.tsx`
- `src/features/academy/academy.module.css`
- `src/features/academy/components/admin.tsx`
- `src/features/academy/components/comments.tsx`
- `src/features/academy/components/creator.tsx`
- `src/features/academy/components/editor.tsx`
- `src/features/academy/domain.ts`
- `src/features/academy/services/read.ts`
- `tests/e2e-app/academy.spec.ts`
- `tests/unit/academy-schema.test.ts`
- `src/features/workspace/components/navigation.tsx`
- `src/features/admin/components/nav-items.ts`
- `src/app/(protected)/app/desafios/[slug]/page.tsx`
- `src/features/workspace/components/challenges-screen.tsx`
