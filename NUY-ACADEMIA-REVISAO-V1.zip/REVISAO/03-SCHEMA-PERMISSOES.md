# Proposta aditiva de schema, índices e permissões

**Ainda não aplicada.** A fonte exata está em `infra/appwrite/academy-schema.ts`, versão `academy-001-proposal`, fora do provisioner v001. Texto é `varchar(255)`, salvo tamanho explícito; `#` inteiro, `!` booleano, `@` datetime e `?` opcional.

| Tabela | Colunas propostas | Chaves únicas | Índices |
| --- | --- | --- | --- |
| `academy_categories` | slug, name, description(1000)?, order#, active! | slug | (active, order) |
| `academy_courses` | slug, title, summary(1000), description(6000)?, categoryId?, coverFileId?, status, order#, publishedAt@?, version# | slug | (status, order), (categoryId, status) |
| `academy_modules` | courseId, title, summary(1000)?, order# | nenhuma | (courseId, order) |
| `academy_lessons` | courseId, moduleId, title, summary(2000)?, durationSeconds#?, videoFileId?, status, order#, publishedAt@? | nenhuma | (courseId, status), (moduleId, order) |
| `academy_materials` | courseId, lessonId?, title, kind, fileId?, url(2048)?, order# | nenhuma | (courseId, order), (lessonId, order) |
| `academy_progress` | userId, courseId, lessonId, completedAt@ | (userId, lessonId) | (userId, courseId) |
| `community_comments` | targetType, targetId, parentId?, authorId, body(4000), status, createdAt@, editedAt@? | nenhuma | (targetType, targetId), (parentId), (authorId, createdAt) |
| `community_reports` | commentId, reporterId, reason(1000), status, reviewedBy?, reviewedAt@? | (commentId, reporterId) | (status), (commentId) |

`status`, `kind` e `targetType` exigem validação no serviço: o manifesto os declara como texto. Revisar referências, limites da instância, índices e rollback antes de migrar.

## Política de acesso proposta

| Recurso | Leitura | Escrita |
| --- | --- | --- |
| Categorias | Creator elegível lê ativas; `manage-catalog` lê todas. | Serviço com `manage-catalog`. |
| Cursos | Creator elegível lê publicados; `manage-catalog` lê rascunhos e arquivados. | Serviço com `manage-catalog`, validando estado e versão. |
| Módulos, aulas, materiais | Creator elegível lê apenas filhos de curso/aula publicados; `manage-catalog` lê todos. | Serviço com `manage-catalog`; publicação ajusta ACL dos filhos. |
| Progresso | Creator lê só linhas próprias; `view-audit` recebe resumo mínimo. | Servidor deriva `userId`, valida aula publicada e grava linha única. |
| Comentários | Creator lê visíveis de alvo publicado; `moderate` lê fila completa. | Servidor deriva autor/alvo; autor altera próprios; moderação exige `moderate` e auditoria. |
| Denúncias | Apenas equipe `moderate`; sem leitura pública. | Servidor deriva denunciante, impede autodenúncia/duplicidade; resolução exige `moderate` e auditoria. |

Filtros da interface não substituem permissões por linha. Não conceder leitura ampla de tabela: uma chamada direta à API poderia expor rascunhos, progresso ou denúncias. Comprovar ACL por linha/arquivo ou serviço equivalente em staging antes de ativar a flag.

## Bucket `academy-media`

Proposta: `public=false`, `fileSecurity=true`, extensões `mp4`/`pdf`, MIME `video/mp4`/`application/pdf`. Upload exclusivo de Admin autorizado, direto e em chunks se a versão suportar. Acesso temporário requer sessão e autorização por aula. Validar limite, espaço, tráfego, play/pause/seek, byte-range, mobile, expiração, inexistente e cleanup. Nenhuma API key no browser e nenhum MP4 integral via Vercel Functions. O bucket não foi criado.
