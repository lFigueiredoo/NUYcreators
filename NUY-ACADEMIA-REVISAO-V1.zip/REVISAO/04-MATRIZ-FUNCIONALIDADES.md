# Matriz de funcionalidades

| Funcionalidade | Estado | Evidência ou dependência |
| --- | --- | --- |
| Menus e proteção de rota | Funcional localmente | E2E com Creator, Admin e visitante no stub. |
| Catálogo, busca e filtro | Funcional localmente | Filtragem sobre fixtures isoladas. |
| Detalhe, aulas, materiais em leitura | Dependente de Appwrite | Interfaces e consultas prontas; sem tabelas, estado de preparação. |
| Editor, ordem local e prévia | Funcional localmente | Estado perdido ao sair da página. |
| Salvar, publicar, arquivar, categorias | Bloqueada por segurança | Controles desabilitados até migração, autorização e auditoria. |
| Player HTML5 | Somente interface | Renderizado só com URL privada autorizada, ainda não emitida. |
| Upload MP4/PDF e abertura de PDF privado | Bloqueada por segurança | Bucket e validação de acesso/byte-range pendentes. |
| Conversa em leitura por aula/desafio | Dependente de Appwrite | E2E usa fixture local. |
| Comentar, responder, editar/excluir, denunciar | Bloqueada por segurança | Autoria e moderação pendentes. |
| Fila Admin de comentários/denúncias | Dependente de Appwrite | Interface e consultas; E2E usa fixture. |
| Moderar e resolver denúncia | Bloqueada por segurança | Comandos e auditoria pendentes. |
| Progresso/conclusão individual | Bloqueada por segurança | Tabela privada e comandos pendentes. |
| Estados vazios e indisponíveis | Funcional localmente | Flag falsa evita consultar tabelas ausentes. |

“Funcional localmente” descreve interface e stub, não persistência remota.
