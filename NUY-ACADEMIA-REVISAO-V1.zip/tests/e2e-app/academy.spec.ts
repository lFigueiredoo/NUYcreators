import { mkdir } from 'node:fs/promises';
import { expect, test, type Page } from '@playwright/test';
import { startStack, type StackHandle } from '../support/stack.mjs';

let stack: StackHandle;
const destination = 'artifacts/academy';

test.beforeAll(async () => {
  await mkdir(destination, { recursive: true });
  stack = await startStack({ academyTest: true });
});
test.afterAll(async () => {
  await stack?.close();
});

async function signIn(page: Page, email: string, password: string) {
  await page.goto(`${stack.origin}/login`);
  await page.fill('input[name="email"]', email);
  await page.fill('input[name="password"]', password);
  await Promise.all([
    page.waitForURL((url) => !url.pathname.startsWith('/login')),
    page.getByRole('button', { name: /entrar/i }).click(),
  ]);
}

test('creator vê catálogo, detalhe, aula e controles privados em três tamanhos', async ({
  page,
}) => {
  await signIn(page, 'ana@nuy.test', 'senha-de-teste-123');
  for (const [width, height] of [
    [1440, 900],
    [390, 844],
    [375, 667],
  ]) {
    await page.setViewportSize({ width, height });
    await page.goto(`${stack.origin}/app/academia`);
    await expect(
      page.getByRole('heading', { name: 'Aprender juntas transforma o que criamos.' }),
    ).toBeVisible();
    if (width < 780) {
      await page.getByRole('button', { name: 'Mais' }).click();
      await expect(page.getByRole('link', { name: 'Academia NUY' })).toBeVisible();
      await page.keyboard.press('Escape');
    } else {
      await expect(page.getByRole('link', { name: 'Academia NUY' })).toBeVisible();
    }
    await expect(page.getByRole('link', { name: /Presença com propósito/ })).toBeVisible();
    await expect(page.getByText('Rascunho interno')).toHaveCount(0);
    await page.screenshot({
      path: `${destination}/creator-catalogo-${width}x${height}.png`,
      fullPage: true,
    });
    await page.getByRole('link', { name: /Presença com propósito/ }).click();
    await expect(page.getByRole('heading', { name: 'Seu percurso' })).toBeVisible();
    await page.screenshot({
      path: `${destination}/creator-detalhe-${width}x${height}.png`,
      fullPage: true,
    });
    await page.getByRole('link', { name: /A voz que é sua/ }).click();
    await expect(page.getByText(/Reprodução privada disponível após/)).toBeVisible();
    await expect(page.getByRole('button', { name: 'Marcar como concluída' })).toBeDisabled();
    await expect(page.getByRole('button', { name: 'Abrir PDF' })).toBeDisabled();
    await expect(page.getByText('Essa aula me ajudou a organizar minhas ideias.')).toBeVisible();
    await expect(page.locator('video[src]')).toHaveCount(0);
    await page.screenshot({
      path: `${destination}/creator-aula-${width}x${height}.png`,
      fullPage: true,
    });
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth > innerWidth + 1,
    );
    expect(overflow).toBe(false);
  }
});

test('permissões: creator não abre Admin e visitante não abre Academia', async ({ page }) => {
  await page.goto(`${stack.origin}/app/academia`);
  await expect(page).toHaveURL(/\/login/);
  await signIn(page, 'ana@nuy.test', 'senha-de-teste-123');
  await page.goto(`${stack.origin}/admin/academia`);
  await expect(page).toHaveURL(/\/app\?access=denied/);
});

test('busca e categoria filtram o catálogo sem mostrar rascunhos', async ({ page }) => {
  await signIn(page, 'ana@nuy.test', 'senha-de-teste-123');
  await page.goto(`${stack.origin}/app/academia`);
  await page.getByRole('searchbox', { name: 'Buscar conteúdo' }).fill('comunidade');
  await page.getByRole('button', { name: 'Buscar' }).click();
  await expect(page.getByRole('link', { name: /Comunidade que cresce junto/ })).toBeVisible();
  await expect(page.getByRole('link', { name: /Presença com propósito/ })).toHaveCount(0);
  await page.getByRole('combobox', { name: 'Filtrar por categoria' }).selectOption('cat-criacao');
  await page.getByRole('button', { name: 'Buscar' }).click();
  await expect(
    page.getByRole('heading', { name: 'Nenhum resultado para este filtro' }),
  ).toBeVisible();
  await expect(page.getByText('Rascunho interno')).toHaveCount(0);
});

test('Admin vê gestão e editor com prévia local sem persistência', async ({ page }) => {
  await signIn(page, 'academy-admin@nuy.test', 'senha-de-teste-academy');
  for (const [width, height] of [
    [1440, 900],
    [390, 844],
    [375, 667],
  ]) {
    await page.setViewportSize({ width, height });
    await page.goto(`${stack.origin}/admin/academia`);
    await expect(page.getByRole('heading', { name: 'Academia NUY', level: 1 })).toBeVisible();
    await expect(page.getByRole('link', { name: 'Novo treinamento' })).toBeVisible();
    await page.screenshot({
      path: `${destination}/admin-lista-${width}x${height}.png`,
      fullPage: true,
    });
    await page.goto(`${stack.origin}/admin/academia/categorias`);
    await expect(page.getByRole('heading', { name: 'Categorias', level: 1 })).toBeVisible();
    await page.screenshot({
      path: `${destination}/admin-categorias-${width}x${height}.png`,
      fullPage: true,
    });
    await page.goto(`${stack.origin}/admin/academia/comentarios`);
    await expect(page.getByRole('heading', { name: 'Comentários', level: 1 })).toBeVisible();
    await expect(page.getByText('Aula · lesson-voz')).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Denúncias' })).toBeVisible();
    await expect(page.getByText('Verificar o contexto deste comentário.')).toBeVisible();
    await page.screenshot({
      path: `${destination}/admin-comentarios-${width}x${height}.png`,
      fullPage: true,
    });
    await page.goto(`${stack.origin}/admin/academia/progresso`);
    await expect(page.getByRole('heading', { name: 'Progresso', level: 1 })).toBeVisible();
    await page.screenshot({
      path: `${destination}/admin-progresso-${width}x${height}.png`,
      fullPage: true,
    });
    await page.goto(`${stack.origin}/admin/academia`);
    await page.getByRole('link', { name: /Presença com propósito/ }).click();
    await expect(page.getByRole('textbox', { name: 'Título' })).toHaveValue(
      'Presença com propósito',
    );
    await page.goto(`${stack.origin}/admin/academia`);
    await page.getByRole('link', { name: 'Novo treinamento' }).click();
    await page.getByRole('textbox', { name: 'Título' }).fill('Treinamento em revisão');
    await page.getByRole('combobox', { name: 'Categoria' }).selectOption('cat-criacao');
    await page.getByRole('button', { name: 'Adicionar módulo' }).click();
    await page.getByRole('button', { name: 'Adicionar aula' }).click();
    await expect(page.getByText('Treinamento em revisão').last()).toBeVisible();
    await expect(page.getByRole('button', { name: 'Salvar rascunho' })).toBeDisabled();
    await expect(page.getByText('Nada foi salvo.')).toBeVisible();
    await page.evaluate(() => {
      (document.activeElement as HTMLElement | null)?.blur();
      window.scrollTo(0, 0);
    });
    await page.screenshot({
      path: `${destination}/admin-editor-${width}x${height}.png`,
      fullPage: true,
    });
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth > innerWidth + 1,
    );
    expect(overflow).toBe(false);
  }
});
