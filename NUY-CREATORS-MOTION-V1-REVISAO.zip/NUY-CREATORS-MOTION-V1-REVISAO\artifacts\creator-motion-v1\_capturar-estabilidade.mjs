/**
 * Screenshots de estabilidade visual do estado ATUAL — para o pacote de revisão.
 *
 * Por que existe: o pacote de revisão pede "screenshots existentes de estabilidade
 * visual", e os que existem no repositório são de 6/out — quatro rodadas atrás,
 * de uma interface que já não é esta (mostram as iniciais no catálogo, antes da
 * rodada das imagens de produto, e outro cromo). Serviriam para confundir, não
 * para comparar. Este script levanta a mesma pilha da suíte e fotografa o REPOUSO
 * do estado atual: nada aqui toca em código, CSS ou animação — é leitura.
 *
 * Vive em `artifacts/` de propósito: o diretório é ignorado pelo git, então a
 * árvore rastreada do repositório não ganha nenhum arquivo novo.
 *
 * Espera o repouso pela régua dura (`getAnimations()` vazio), e não por relógio:
 * é exatamente o que a §19 quer medir — se alguma entrada deixasse `transform`
 * residual, aqui apareceria tanto na imagem quanto no JSON.
 */
import fs from 'node:fs/promises';
import { chromium } from '@playwright/test';
import { startStack } from '../../tests/support/stack.mjs';

const DIR = 'artifacts/creator-motion-v1/estabilidade-visual';
const USER = { email: 'ana@nuy.test', password: 'senha-de-teste-123' };

const ROUTES = [
  ['painel', '/app'],
  ['desafios', '/app/desafios'],
  ['conteudos', '/app/conteudos'],
  ['pontos', '/app/pontos'],
  ['recompensas', '/app/recompensas'],
  ['ranking', '/app/ranking'],
  ['notificacoes', '/app/notificacoes'],
  ['perfil', '/app/perfil'],
];

const VIEWPORTS = [
  ['1440', { width: 1440, height: 900 }],
  ['390', { width: 390, height: 844, mobile: true }],
];

const probe = () => {
  const describe = (node) => {
    const style = getComputedStyle(node);
    return {
      tag: node.tagName.toLowerCase(),
      classes: [...node.classList].filter((name) => /__(enter|i\d)$/.test(name)).join(' '),
      transform: style.transform,
      rodando: node
        .getAnimations()
        .filter((animation) => animation.playState === 'running')
        .map((animation) => animation.animationName),
    };
  };
  const nodes = [...document.querySelectorAll('[class*="__enter"]')];
  return {
    elementosComEntrada: nodes.length,
    transformResidual: nodes.map(describe).filter((element) => element.transform !== 'none').length,
    animacoesRodando: document.getAnimations().filter((a) => a.playState === 'running').length,
    overflowHorizontal: document.documentElement.scrollWidth - window.innerWidth,
  };
};

await fs.mkdir(DIR, { recursive: true });
const stack = await startStack();
const browser = await chromium.launch({ headless: false });
const report = { origem: stack.origin, telas: {} };

async function signIn(page) {
  await page.goto(`${stack.origin}/login`, { waitUntil: 'domcontentloaded' });
  await page.fill('input[name="email"]', USER.email);
  await page.fill('input[name="password"]', USER.password);
  await Promise.all([
    page.waitForURL((url) => !url.pathname.startsWith('/login'), { timeout: 30_000 }),
    page.click('button[type="submit"]'),
  ]);
}

try {
  for (const [label, viewport] of VIEWPORTS) {
    const context = await browser.newContext({
      viewport,
      isMobile: Boolean(viewport.mobile),
      hasTouch: Boolean(viewport.mobile),
      ignoreHTTPSErrors: true,
      locale: 'pt-BR',
      reducedMotion: 'no-preference',
      deviceScaleFactor: 2,
    });
    const page = await context.newPage();
    try {
      await signIn(page);
      report.telas[label] = {};
      for (const [name, route] of ROUTES) {
        await page.goto(`${stack.origin}${route}`, { waitUntil: 'domcontentloaded' });
        await page.getByRole('heading', { level: 1 }).first().waitFor();
        // Repouso pela régua dura: nenhuma animação rodando + uma folga curta.
        await page
          .waitForFunction(
            () => document.getAnimations().every((animation) => animation.playState !== 'running'),
            null,
            { timeout: 10_000 },
          )
          .catch(() => {});
        await page.waitForTimeout(400);
        report.telas[label][name] = await page.evaluate(probe);
        await page.screenshot({ path: `${DIR}/${label}-${name}.png` });
        const medida = report.telas[label][name];
        console.log(
          `[${label}-${name}] residual ${medida.transformResidual} · ` +
            `rodando ${medida.animacoesRodando} · overflow ${medida.overflowHorizontal}px`,
        );
        await fs.writeFile(`${DIR}/repouso.json`, `${JSON.stringify(report, null, 2)}\n`);
      }
    } finally {
      await context.close();
    }
  }
} finally {
  await browser.close();
  await stack.close();
}

console.log(`\n[sondas] ${DIR}/repouso.json`);
