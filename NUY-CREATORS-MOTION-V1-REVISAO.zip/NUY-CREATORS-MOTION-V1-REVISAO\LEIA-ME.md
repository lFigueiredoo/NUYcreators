# NUY Creators — Pacote de revisão · Motion V1

**Data do pacote:** 2026-10-09 · **árvore:** `master`, mudanças **sem commit** · **alvo da revisão:** a fluidez, antes de autorizar o commit.

Este pacote é **somente leitura**: nada de código, CSS ou animação foi alterado para produzi-lo.

---

## O que tem aqui

```
NUY-CREATORS-MOTION-V1-REVISAO/
├── LEIA-ME.md                          ← este arquivo
├── artifacts/creator-motion-v1/
│   ├── a-painel-1440.webm              A. Painel — carregamento
│   ├── b-navegacao-1440.webm           B. Navegação entre as 8 telas
│   ├── c-cards-hover-1440.webm         C. Hover dos cards
│   ├── d-abas-desafios-1440.webm       D. Abas de desafios
│   ├── e-recompensas-1440.webm         E. Recompensas
│   ├── f-mais-390.webm                 F. Menu "Mais" no mobile
│   ├── g-landing-1440.webm             G. Landing — scroll/reveal
│   ├── r-reduce-1440.webm              R. prefers-reduced-motion (controle)
│   ├── quadros.json                    ← a sonda numérica de cada clipe
│   ├── _capturar-estabilidade.mjs      ← como os screenshots abaixo foram feitos
│   └── estabilidade-visual/
│       ├── 1440-*.png (8)              ← repouso, desktop 1440
│       ├── 390-*.png (8)               ← repouso, mobile 390
│       └── repouso.json                ← a sonda numérica de cada tela
└── docs/delivery-creator-motion-v1.md  ← a entrega §21 completa
```

## Os vídeos são os originais

**Nenhum vídeo foi acelerado, recortado, reconvertido ou reeditado.** São cópia byte a byte da gravação; a única operação foi copiar para dentro do ZIP. Duram o que durou a gravação:

| clipe                      | duração | resolução | fps |
| -------------------------- | ------- | --------- | --- |
| `a-painel-1440.webm`       | 4,12s   | 1440×900  | 25  |
| `b-navegacao-1440.webm`    | 16,40s  | 1440×900  | 25  |
| `c-cards-hover-1440.webm`  | 9,56s   | 1440×900  | 25  |
| `d-abas-desafios-1440.webm`| 8,00s   | 1440×900  | 25  |
| `e-recompensas-1440.webm`  | 6,40s   | 1440×900  | 25  |
| `f-mais-390.webm`          | 7,36s   | 390×844   | 25  |
| `g-landing-1440.webm`      | 10,52s  | 1440×900  | 25  |
| `r-reduce-1440.webm`       | 6,24s   | 1440×900  | 25  |

Os `sha256` de cada arquivo estão no fim deste documento: servem para conferir que o que você abrir é exatamente o que foi gravado.

**Os vídeos foram gravados com GPU real** (`headless: false`), e não em modo headless por software: em headless o movimento engasga e o vídeo provaria o contrário do que o sprint entregou.

## `quadros.json` — a prova de fluidez

Imagem estática não prova fluidez, então ao lado de cada clipe saiu uma medição de intervalo entre quadros (`requestAnimationFrame`), com a **posição** de cada engasgo medida do primeiro quadro. Resumo:

| clipe                  | p50     | p95     | quadros > 33ms |
| ---------------------- | ------- | ------- | -------------- |
| A painel               | 16,7ms  | 17,2ms  | 4              |
| B navegação            | 16,7ms  | 16,9ms  | 6              |
| C hover                | 16,7ms  | 16,9ms  | **0**          |
| D abas                 | 16,7ms  | 16,9ms  | 2              |
| E recompensas          | 16,7ms  | 17,0ms  | 1              |
| F "Mais" mobile        | 16,7ms  | 17,0ms  | **0**          |
| G landing              | 16,7ms  | 16,8ms  | 9              |
| R reduced-motion       | 16,7ms  | 17,0ms  | **0**          |

p50 de **16,7ms em todos os oito** = travado em 60Hz. Os picos ficam na primeira pintura (imagens) e na troca de rota (dados + Suspense) — trabalho pré-existente, não a coreografia desta rodada. O campo `picosEmMs` do JSON diz **quando** cada um caiu, para separar uma coisa da outra.

## `estabilidade-visual/` — screenshots do repouso

**Estes screenshots foram capturados hoje, no CSS final** — 8 telas × 2 larguras (1440 e 390), no estado de repouso, com a espera pela régua dura (nenhuma animação rodando) e não por relógio.

Uma ressalva que importa: os screenshots de tela que já existiam no repositório são de **6 de outubro** e mostram uma interface de **quatro rodadas atrás** (trazem, por exemplo, as iniciais no catálogo, de antes da rodada das imagens de produto, e outro cromo). Eles **não** foram usados aqui: ao lado dos vídeos, sugeririam uma diferença que não existe. Os que estão neste pacote são do estado que você vai aprovar.

`repouso.json` traz, por tela: `transformResidual`, `animacoesRodando` e `overflowHorizontal`. Os três zerados em todas as 16 — **residual 0** significa que nenhuma entrada deixa `transform` grudado no repouso (que é o que criaria contexto de pilha e bloco contentor).

## Como revisar

1. **Comece por `b-navegacao-1440.webm` e `f-mais-390.webm`** — são os que mais dizem sobre a sensação de fluidez.
2. **`c-cards-hover-1440.webm`** mostra o hover sem nenhum vizinho se mexer.
3. **`r-reduce-1440.webm`** é o controle: a mesma interface com `prefers-reduced-motion`, sem movimento.
4. **`g-landing-1440.webm`** é a landing pública rolando (reveal por seção, preservado — nada duplicado).
5. Compare as posições do repouso com os `estabilidade-visual/*.png` se quiser checar deslocamento de layout.

## O que ficou de fora, e por quê

- **`artifacts/creator-motion-v1/video/`** — são as gravações cruas do Playwright, com nome por hash. Essa pasta mistura a execução final com execuções **anteriores** à correção do `animation-fill-mode` (as de 13:51–13:58). Como não há como distinguir uma da outra pelo nome, incluí-las colocaria ao lado dos clipes bons um material que já foi corrigido — sem rótulo. Se quiser, elas são recuperáveis.
- **`docs/delivery-creator-redesign-*` e as demais entregas** — fora do escopo desta revisão.

## `sha256` dos vídeos

```
9e50207f908d76509d4ca8cd4979c21b546eac46354299fc4e7ebefd30793915  a-painel-1440.webm
a8996a8a2045667823a31804aabe066c0bae717c0c31345cb005733379e7fa24  b-navegacao-1440.webm
289adcf45996c301faf4b89967723642db0c034f0bf4d7ea88d196c0aa96f5ed  c-cards-hover-1440.webm
65156f57dfc7a0480019649a43928c7fde6aa8adc2f114eed6d6b1c82bfbeeee  d-abas-desafios-1440.webm
85e4a2236ef8d2149611ac20109ebd6e6b4b49b2e86ed7bb303a1a2677af7b79  e-recompensas-1440.webm
4a416aa0353e0cf646a5dbe0da956b845a66d3864b999767d18f5cff0a403b8a  f-mais-390.webm
96b6b9cd785209cb2b3d54db66aacb503b1e969a4e9deae27f61ae9ec2cd67d3  g-landing-1440.webm
9893153af95b622f8fe28f1d17424c2df2e0225dc6605d5b8fbec9c5e5b59523  r-reduce-1440.webm
```
